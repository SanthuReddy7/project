from django.apps import AppConfig


class LongitudeParkingConfig(AppConfig):
    name = 'longitude_parking'
